/* OLD MESSENGER - Messenger call (group + inbox): each user's own tile shows his profile pic
   as a soft white-hazy blurred background, the round pic stays in the centre, plus Fullscreen button. */
(function () {
  try {
    if (window.__dmCallTiles17) return;
    window.__dmCallTiles17 = 1;
    if (!/messenger\.com|facebook\.com/.test(location.host)) return;

    var st = document.createElement('style');
    st.textContent =
      /* square tile (rounded corners): profile pic fills it, sharp and clear */
      '.dm-tile{position:relative!important;overflow:hidden!important;isolation:isolate!important;border-radius:14px!important;background:#1c1d1f!important}' +
      '.dm-bg{position:absolute!important;left:0!important;top:0!important;width:100%!important;height:100%!important;z-index:0!important;background-size:cover!important;background-position:center!important;background-repeat:no-repeat!important;pointer-events:none!important;' +
      'filter:brightness(.88) saturate(1.1)!important;-webkit-filter:brightness(.88) saturate(1.1)!important}' +
      /* soft square shade over the picture so the round pic and the name stay readable */
      '.dm-bg::after{content:""!important;position:absolute!important;left:0;top:0;right:0;bottom:0;' +
      'background:linear-gradient(to bottom,rgba(0,0,0,.10) 0%,rgba(0,0,0,0) 35%,rgba(0,0,0,.50) 100%)!important}' +
      '.dm-tile .dm-clear{background:transparent!important;background-color:transparent!important;background-image:none!important;backdrop-filter:none!important;-webkit-backdrop-filter:none!important}' +
      /* round picture in the centre with a white ring */
      '.dm-avatar{position:relative!important;z-index:2!important;border-radius:50%!important;object-fit:cover!important;filter:none!important;' +
      'box-shadow:0 0 0 3px #fff,0 0 0 9px rgba(255,255,255,.28),0 6px 22px rgba(0,0,0,.45)!important}' +
      '#dm-fs{position:fixed;top:8px;right:8px;z-index:2147483647;display:flex;align-items:center;gap:6px;padding:7px 12px;border-radius:999px;' +
      'background:rgba(10,20,30,.82);color:#fff;font:600 13px/1 sans-serif;border:1.5px solid #22d3ee;box-shadow:0 2px 10px rgba(0,0,0,.5)}';
    (document.head || document.documentElement).appendChild(st);

    function R(e) { return e.getBoundingClientRect(); }

    function isAvatar(img) {
      var r = R(img);
      if (r.width < 40 || r.width > 460 || r.height < 40) return false;
      if (Math.abs(r.width - r.height) > r.width * 0.18) return false;
      var cs = getComputedStyle(img), p = img.parentElement, pcs = p ? getComputedStyle(p) : null;
      var br = cs.borderRadius + ' ' + (pcs ? pcs.borderRadius : '');
      return /50%|9999|999px|[1-9]\d{2,}px|^[2-9]\d+px/.test(br) || r.width >= 60;
    }

    function countAvatars(e) {
      var imgs = e.querySelectorAll('img'), c = 0;
      for (var i = 0; i < imgs.length; i++) if (isAvatar(imgs[i])) c++;
      return c;
    }

    // the whole rounded user box: biggest ancestor that holds only this one avatar (not a full row / screen)
    function btnCount(e) { return e.querySelectorAll('button,[role=button]').length; }

    function tileOf(img, solo) {
      var a = R(img), e = img.parentElement, n = 0, first = null, rounded = null, narrow = null, vp = innerWidth * innerHeight;
      var maxArea = solo ? vp * 0.95 : vp * 0.5;
      while (e && e !== document.body && n++ < 9) {
        var r = R(e), area = r.width * r.height, ratio = r.width / (r.height || 1);
        if (area > maxArea) break;                       // never the whole screen / control layer
        if (countAvatars(e) !== 1) break;                // must hold only this one user
        if (!solo && btnCount(e) > 2) break;             // control bar area is not a user box
        if (r.width >= a.width * 1.3 && r.height >= a.height * 1.08 && ratio > 0.4 && ratio < 3.4) {
          if (!first) first = e;
          var rad = parseFloat(getComputedStyle(e).borderTopLeftRadius) || 0;
          if (rad > 2) rounded = e;
          if (r.width < innerWidth * 0.62) narrow = e;
        }
        e = e.parentElement;
      }
      return rounded || narrow || first;
    }

    // keep the round pic exactly in the middle of the whole box
    function centre(tile, img) {
      var t = R(tile), a = R(img), old = img.__dx || 0;
      var dx = (t.left + t.width / 2) - ((a.left + a.width / 2) - old);
      if (Math.abs(dx - old) > 1.5) { img.__dx = dx; img.style.setProperty('transform', 'translateX(' + dx.toFixed(1) + 'px)', 'important'); }
    }

    function hasLive(tile) {
      var v = tile.querySelectorAll('video');
      for (var i = 0; i < v.length; i++) if (v[i].videoWidth > 0 && !v[i].paused && v[i].readyState > 2) return true;
      return false;
    }

    function setup(tile, img) {
      var bg = tile.querySelector(':scope > .dm-bg');
      if (!bg) {
        bg = document.createElement('div');
        bg.className = 'dm-bg';
        tile.insertBefore(bg, tile.firstChild);
      }
      var src = img.currentSrc || img.src;
      // default (no profile pic) avatars come from Facebook's static assets / svg -> plain grey tile
      var isDefault = /static\.[^\/]*fbcdn|rsrc\.php|\.svg(\?|$)|^data:image\/svg/i.test(src);
      if (bg.__src !== src) {
        bg.__src = src;
        bg.style.backgroundImage = isDefault ? 'none' : 'url("' + src.replace(/"/g, '%22') + '")';
        bg.style.backgroundColor = isDefault ? '#3a3b3c' : '';
      }
      tile.classList.add('dm-tile');
      img.classList.add('dm-avatar');
      var all = tile.querySelectorAll('*');
      for (var k = 0; k < all.length; k++) {
        var el = all[k];
        if (el === img || el === bg || el.className === 'dm-bg') continue;
        if (el.tagName === 'VIDEO' || el.tagName === 'IMG' || el.tagName === 'svg' || el.closest('svg')) continue;
        var ctrl = el.querySelector('button,[role=button],svg');
        if (ctrl && !el.contains(img)) continue;
        el.classList.add('dm-clear');
      }
    }

    function run() {
      var imgs = document.querySelectorAll('img'), list = [], i;
      for (i = 0; i < imgs.length; i++) if (imgs[i].src && isAvatar(imgs[i])) list.push(imgs[i]);
      var solo = list.length <= 2;
      for (i = 0; i < list.length; i++) {
        var img = list[i];
        var tile = tileOf(img, solo);
        if (!tile) { if (img.__dx) { img.__dx = 0; img.style.removeProperty('transform'); } continue; }
        var live = hasLive(tile);
        var bg = tile.querySelector(':scope > .dm-bg');
        if (live) { if (bg) bg.style.display = 'none'; continue; }
        if (bg) bg.style.display = '';
        setup(tile, img);
        centre(tile, img);
      }
    }

    // ---------- Fullscreen / Exit Fullscreen ----------
    var fs = null;
    function isFs() { return !!(document.fullscreenElement || document.webkitFullscreenElement); }
    function updateFs() {
      var inCall = /call/i.test(location.pathname);
      if (!inCall) { if (fs) { fs.remove(); fs = null; } return; }
      if (!fs) {
        fs = document.createElement('div');
        fs.id = 'dm-fs';
        fs.addEventListener('click', function (ev) {
          ev.stopPropagation();
          try {
            if (isFs()) { (document.exitFullscreen || document.webkitExitFullscreen).call(document); }
            else { var d = document.documentElement; (d.requestFullscreen || d.webkitRequestFullscreen).call(d); }
          } catch (e) {}
        }, true);
        (document.body || document.documentElement).appendChild(fs);
      }
      fs.textContent = isFs() ? '\u2715  Exit Fullscreen' : '\u26F6  Fullscreen';
    }
    document.addEventListener('fullscreenchange', updateFs);
    document.addEventListener('webkitfullscreenchange', updateFs);

    function tick() { try { run(); updateFs(); } catch (e) {} }
    var t = 0;
    new MutationObserver(function () { if (!t) t = setTimeout(function () { t = 0; tick(); }, 350); })
      .observe(document.documentElement, { childList: true, subtree: true });
    setInterval(tick, 1200);
    tick();
  } catch (e) {}
})();
