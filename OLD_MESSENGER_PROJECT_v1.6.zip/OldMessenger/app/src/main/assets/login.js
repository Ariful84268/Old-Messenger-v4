/* OLD MESSENGER: login pages only. Safe branding: never removes or edits Facebook's own page elements
   (that can break the login form). It only hides the Facebook logo with CSS and floats a Messenger logo. */
(function () {
  try {
    if (window.__omLogin) return;
    window.__omLogin = 1;
    if (!/facebook\.com|messenger\.com/.test(location.host)) return;

    var LOGO = 'data:image/svg+xml;utf8,' + encodeURIComponent(
      '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 96 96">' +
      '<defs><linearGradient id="g" x1="0" y1="1" x2="1" y2="0">' +
      '<stop offset="0" stop-color="#0099ff"/><stop offset=".6" stop-color="#a033ff"/>' +
      '<stop offset="1" stop-color="#ff5280"/></linearGradient></defs>' +
      '<path fill="url(#g)" d="M48 6C24 6 6 23.6 6 47.4c0 12.5 5 23.2 13.1 30.5 .7 .6 1.1 1.5 1.1 2.4l.2 7.6c.1 2.4 2.6 4 4.8 3l8.5-3.7c.7-.3 1.5-.4 2.2-.2 3.9 1.1 8 1.6 12.1 1.6 24 0 42-17.6 42-41.2S72 6 48 6z"/>' +
      '<path fill="#fff" d="M20 60.5l17.6-27.9c1.8-2.8 5.6-3.5 8.3-1.5l14 10.5c1.3 .9 3 .9 4.2 0l18.9-14.3c2.5-1.9 5.8 1.1 4.1 3.7L69.5 58.9c-1.8 2.8-5.6 3.5-8.3 1.5l-14-10.5c-1.3-.9-3-.9-4.2 0L24.1 64.2c-2.5 1.9-5.8-1.1-4.1-3.7z"/>' +
      '</svg>');

    var st = document.createElement('style');
    st.textContent =
      'img[alt="Facebook"],svg[aria-label="Facebook"],[role="img"][aria-label="Facebook"]{visibility:hidden!important}' +
      '#om-login-logo{position:fixed;top:14px;left:50%;transform:translateX(-50%);width:64px;height:64px;' +
      'z-index:2147483000;pointer-events:none}';
    (document.head || document.documentElement).appendChild(st);

    function add() {
      if (!document.body || document.getElementById('om-login-logo')) return;
      var i = document.createElement('img');
      i.id = 'om-login-logo'; i.src = LOGO; i.alt = '';
      document.body.appendChild(i);
      document.title = document.title.replace(/Facebook/g, 'Messenger');
    }
    if (document.body) add(); else document.addEventListener('DOMContentLoaded', add);
  } catch (e) {}
})();
