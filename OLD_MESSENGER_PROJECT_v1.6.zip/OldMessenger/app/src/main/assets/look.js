/* OLD MESSENGER: make facebook.com/messages look like the Messenger app (no Facebook top bar). */
(function () {
  try {
    if (window.__omLook) return;
    window.__omLook = 1;
    if (!/facebook\.com|messenger\.com/.test(location.host)) return;
    var st = document.createElement('style');
    st.id = 'om-look';
    st.textContent =
      'html,body{background:#000!important}' +
      'body.om-msg div[role="banner"]{display:none!important}' +
      'body.om-msg{overscroll-behavior:none}';
    (document.head || document.documentElement).appendChild(st);
    function tick() {
      var b = document.body; if (!b) return;
      var on = /^\/(messages|t\/)/.test(location.pathname);
      b.classList.toggle('om-msg', on);
    }
    new MutationObserver(tick).observe(document.documentElement, { childList: true, subtree: true });
    setInterval(tick, 800); tick();
  } catch (e) {}
})();
