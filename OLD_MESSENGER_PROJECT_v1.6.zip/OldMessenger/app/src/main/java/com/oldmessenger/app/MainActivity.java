package com.oldmessenger.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.PermissionRequest;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import androidx.webkit.WebSettingsCompat;
import androidx.webkit.WebViewFeature;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** OLD MESSENGER: full-screen wrapper around facebook.com/messages. No address bar, no tabs. */
public class MainActivity extends Activity {

    private static final String START_URL = "https://www.facebook.com/messages/";
    private static final int REQ_FILE = 11;
    private static final int REQ_PERM = 12;

    // Desktop Chrome UA: the mobile site pushes "install the app" pages instead of chat.
    private static final String UA =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) "
            + "Chrome/124.0.0.0 Safari/537.36";

    private static final int VIEWPORT_W = 640; // smaller = bigger chat UI

    private FrameLayout rootFrame;
    private View customView;
    private WebChromeClient.CustomViewCallback customCb;
    private WebView web;
    private ProgressBar bar;
    private ValueCallback<Uri[]> fileCb;
    private PermissionRequest pendingWebPerm;

    @SuppressLint({"SetJavaScriptEnabled"})
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        FrameLayout root = new FrameLayout(this);
        rootFrame = root;
        root.setBackgroundColor(0xFF000000);
        web = new WebView(this);
        root.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, (int) (3 * getResources().getDisplayMetrics().density));
        root.addView(bar, lp);
        setContentView(root);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        web.setBackgroundColor(0xFF000000);
        try {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
                WebSettingsCompat.setAlgorithmicDarkeningAllowed(s, true);
            } else if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
                WebSettingsCompat.setForceDark(s, WebSettingsCompat.FORCE_DARK_ON);
            }
        } catch (Throwable ignored) { }
        s.setUserAgentString(UA);
        // Do not tell Facebook which app/WebView is making the request (helps login not get blocked).
        try {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.REQUESTED_WITH_HEADER_ALLOW_LIST)) {
                WebSettingsCompat.setRequestedWithHeaderOriginAllowList(s, Collections.<String>emptySet());
            }
        } catch (Throwable ignored) { }
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(true);

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(web, true);

        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                if (!r.isForMainFrame()) return false;
                Uri u = r.getUrl();
                String sch = u.getScheme() == null ? "" : u.getScheme();
                if (sch.equals("about") || sch.equals("blob") || sch.equals("data")
                        || sch.equals("javascript")) return false;
                if (sch.equals("http") || sch.equals("https")) {
                    if (isInApp(u.getHost())) return false;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception ignored) { }
                return true;
            }
            @Override public void onPageStarted(WebView v, String url, Bitmap f) {
                bar.setVisibility(View.VISIBLE);
            }
            @Override public void onPageCommitVisible(WebView v, String url) {
                inject(v, url);
            }
            @Override public void onPageFinished(WebView v, String url) {
                inject(v, url);
                bar.setVisibility(View.GONE);
                CookieManager.getInstance().flush();
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView v, int p) { bar.setProgress(p); }

            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb,
                                                       FileChooserParams params) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try {
                    startActivityForResult(params.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    fileCb = null;
                    return false;
                }
                return true;
            }

            @Override public void onPermissionRequest(final PermissionRequest req) {
                runOnUiThread(() -> handleWebPermission(req));
            }

            @Override public void onShowCustomView(View view, CustomViewCallback cb) {
                if (customView != null) { cb.onCustomViewHidden(); return; }
                customView = view; customCb = cb;
                view.setBackgroundColor(0xFF000000);
                rootFrame.addView(view, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
            }

            @Override public void onHideCustomView() { hideCustom(); }
        });

        web.setDownloadListener(new DownloadListener() {
            @Override public void onDownloadStart(String url, String ua, String cd, String mime, long len) {
                try {
                    DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
                    r.addRequestHeader("Cookie", CookieManager.getInstance().getCookie(url));
                    r.addRequestHeader("User-Agent", ua);
                    r.setMimeType(mime);
                    r.setNotificationVisibility(
                            DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,
                            URLUtil.guessFileName(url, cd, mime));
                    ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(r);
                    Toast.makeText(MainActivity.this, "Downloading…", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Download failed", Toast.LENGTH_SHORT).show();
                }
            }
        });

        if (b != null) web.restoreState(b); else web.loadUrl(START_URL);
    }

    private void hideCustom() {
        if (customView == null) return;
        rootFrame.removeView(customView);
        customView = null;
        if (customCb != null) customCb.onCustomViewHidden();
        customCb = null;
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
    }

    private String asset(String name) {
        try (InputStream in = getAssets().open(name)) {
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
            return o.toString("UTF-8");
        } catch (Exception e) { return ""; }
    }

    /** Viewport, Messenger-app look, and call-tile backgrounds. Only on Facebook pages. */
    private void inject(WebView v, String url) {
        if (url == null) return;
        try {
            if (!isInApp(Uri.parse(url).getHost())) return;
        } catch (Exception e) { return; }
        String vp = "(function(){try{var C='width=" + VIEWPORT_W + ",minimum-scale=0.1,maximum-scale=10,user-scalable=yes';"
                + "function fix(){var d=document,h=d.head||d.documentElement;if(!h)return;"
                + "var ms=d.querySelectorAll('meta[name=viewport]'),m=ms[0];"
                + "if(!m){m=d.createElement('meta');m.name='viewport';m.content=C;h.appendChild(m);return;}"
                + "for(var i=1;i<ms.length;i++)ms[i].parentNode.removeChild(ms[i]);"
                + "if(m.getAttribute('content')!==C)m.setAttribute('content',C);}"
                + "fix();if(!window.__omVp){window.__omVp=1;new MutationObserver(fix).observe(document.documentElement,"
                + "{childList:true,subtree:true,attributes:true,attributeFilter:['content']});}}catch(e){}})();";
        v.evaluateJavascript(vp, null);
        if (isAuthPath(Uri.parse(url).getPath())) {
            // Login / checkpoint / recovery: touch the page as little as possible.
            String lg0 = asset("login.js");
            if (lg0.length() > 0) v.evaluateJavascript(lg0, null);
            return;
        }
        String look = asset("look.js");
        if (look.length() > 0) v.evaluateJavascript(look, null);
        String ct = asset("calltile.js");
        if (ct.length() > 0) v.evaluateJavascript(ct, null);
    }

    private static boolean isAuthPath(String p) {
        if (p == null) return false;
        p = p.toLowerCase();
        return p.startsWith("/login") || p.startsWith("/recover") || p.startsWith("/checkpoint")
                || p.startsWith("/two_step_verification") || p.startsWith("/privacy/consent")
                || p.startsWith("/cookie") || p.startsWith("/confirmemail") || p.startsWith("/device-based");
    }

    private static boolean isInApp(String h) {
        if (h == null) return false;
        h = h.toLowerCase();
        String[] ok = {"facebook.com", "messenger.com", "fb.com", "fbcdn.net", "facebook.net",
                "fbsbx.com", "m.me"};
        for (String d : ok) if (h.equals(d) || h.endsWith("." + d)) return true;
        return false;
    }

    private void handleWebPermission(PermissionRequest req) {
        List<String> need = new ArrayList<>();
        for (String r : req.getResources()) {
            if (r.equals(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) need.add(Manifest.permission.RECORD_AUDIO);
            if (r.equals(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) need.add(Manifest.permission.CAMERA);
        }
        List<String> missing = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 23) {
            for (String p : need) if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) missing.add(p);
        }
        if (missing.isEmpty()) {
            req.grant(req.getResources());
        } else {
            pendingWebPerm = req;
            requestPermissions(missing.toArray(new String[0]), REQ_PERM);
        }
    }

    @Override public void onRequestPermissionsResult(int code, String[] p, int[] res) {
        super.onRequestPermissionsResult(code, p, res);
        if (code == REQ_PERM && pendingWebPerm != null) {
            boolean all = res.length > 0;
            for (int r : res) if (r != PackageManager.PERMISSION_GRANTED) all = false;
            if (all) pendingWebPerm.grant(pendingWebPerm.getResources()); else pendingWebPerm.deny();
            pendingWebPerm = null;
        }
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_FILE && fileCb != null) {
            fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            fileCb = null;
        }
    }

    @Override protected void onSaveInstanceState(Bundle o) {
        super.onSaveInstanceState(o);
        web.saveState(o);
    }

    @Override public void onBackPressed() {
        if (customView != null) { hideCustom(); return; }
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    @Override protected void onPause() {
        super.onPause();
        CookieManager.getInstance().flush();
    }

    @Override protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
